import java.util.Scanner;
class Demo2{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("���������ݣ�");
		int data = sc.nextInt();
		int num=1;
		System.out.println(data+"�Ľ׳�Ϊ��");
		for(;data>0;data--){
			num*=data;
			if(data==1){
				System.out.print(data);
			}else{
				System.out.print(data+"*");
			}
		}
		System.out.print("="+num+"\n");
	}
}